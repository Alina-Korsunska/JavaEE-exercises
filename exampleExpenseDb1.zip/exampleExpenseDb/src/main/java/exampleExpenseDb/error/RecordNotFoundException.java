package exampleExpenseDb.error;

public class RecordNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public RecordNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
