package exampleExpenseDb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleExpenseDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleExpenseDbApplication.class, args);
	}

}
